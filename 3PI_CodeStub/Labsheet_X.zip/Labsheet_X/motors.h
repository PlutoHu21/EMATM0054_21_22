// this #ifndef stops this file
// from being included mored than
// once by the compiler. 
#ifndef _MOTORS_H
#define _MOTORS_H

// Class to operate the motor(s).
class Motors_c {
  public:
  
    // Constructor, must exist.
    Motors_c() {

    } 

    // Use this function to 
    // initialise the pins and 
    // state of your motor(s).
    void initialise() {

    }

    // Write a function to operate
    // your motor(s)
    // ...

    
};



#endif
